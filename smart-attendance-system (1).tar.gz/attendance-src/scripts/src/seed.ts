import { db, facultyTable, studentsTable, timetableTable } from "@workspace/db";
import bcrypt from "bcryptjs";

async function seed() {
  console.log("Seeding database...");

  // Seed faculty
  const passwordHash = await bcrypt.hash("faculty123", 10);
  const [faculty] = await db
    .insert(facultyTable)
    .values([
      { name: "Dr. Rajesh Kumar", email: "admin@college.edu", passwordHash, department: "Computer Science" },
      { name: "Prof. Priya Sharma", email: "priya@college.edu", passwordHash, department: "Electronics" },
    ])
    .onConflictDoNothing()
    .returning();

  console.log("Faculty seeded");

  // Seed students - CS department
  const csStudents = [
    { name: "Arun Kumar", registerNumber: "CS2021001", department: "Computer Science", year: "3rd Year", section: "A" },
    { name: "Priya Nair", registerNumber: "CS2021002", department: "Computer Science", year: "3rd Year", section: "A" },
    { name: "Rahul Verma", registerNumber: "CS2021003", department: "Computer Science", year: "3rd Year", section: "A" },
    { name: "Sneha Patel", registerNumber: "CS2021004", department: "Computer Science", year: "3rd Year", section: "A" },
    { name: "Vikram Singh", registerNumber: "CS2021005", department: "Computer Science", year: "3rd Year", section: "A" },
    { name: "Deepa Krishnan", registerNumber: "CS2021006", department: "Computer Science", year: "3rd Year", section: "B" },
    { name: "Arjun Mehta", registerNumber: "CS2021007", department: "Computer Science", year: "3rd Year", section: "B" },
    { name: "Kavitha Reddy", registerNumber: "CS2021008", department: "Computer Science", year: "3rd Year", section: "B" },
    { name: "Sanjay Gupta", registerNumber: "CS2021009", department: "Computer Science", year: "2nd Year", section: "A" },
    { name: "Ananya Das", registerNumber: "CS2022001", department: "Computer Science", year: "2nd Year", section: "A" },
    { name: "Rohan Sharma", registerNumber: "CS2022002", department: "Computer Science", year: "2nd Year", section: "A" },
    { name: "Meera Iyer", registerNumber: "CS2022003", department: "Computer Science", year: "2nd Year", section: "B" },
  ];

  const ecStudents = [
    { name: "Kiran Raj", registerNumber: "EC2021001", department: "Electronics", year: "3rd Year", section: "A" },
    { name: "Divya Menon", registerNumber: "EC2021002", department: "Electronics", year: "3rd Year", section: "A" },
    { name: "Suresh Kumar", registerNumber: "EC2021003", department: "Electronics", year: "3rd Year", section: "A" },
    { name: "Lakshmi Devi", registerNumber: "EC2021004", department: "Electronics", year: "3rd Year", section: "B" },
  ];

  await db.insert(studentsTable).values([...csStudents, ...ecStudents]).onConflictDoNothing();
  console.log("Students seeded");

  // Seed timetable
  const timetableEntries = [
    { day: "Monday", timeSlot: "Period 1", startTime: "09:00", endTime: "10:00", subject: "Data Structures", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "A", room: "CS-101" },
    { day: "Monday", timeSlot: "Period 2", startTime: "10:00", endTime: "11:00", subject: "Algorithms", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "B", room: "CS-102" },
    { day: "Monday", timeSlot: "Period 3", startTime: "11:15", endTime: "12:15", subject: "Database Systems", facultyName: "Prof. Priya Sharma", department: "Computer Science", year: "2nd Year", section: "A", room: "CS-201" },
    { day: "Monday", timeSlot: "Period 4", startTime: "13:00", endTime: "14:00", subject: "Operating Systems", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "2nd Year", section: "B", room: "CS-202" },
    { day: "Tuesday", timeSlot: "Period 1", startTime: "09:00", endTime: "10:00", subject: "Computer Networks", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "A", room: "CS-101" },
    { day: "Tuesday", timeSlot: "Period 2", startTime: "10:00", endTime: "11:00", subject: "Machine Learning", facultyName: "Prof. Priya Sharma", department: "Computer Science", year: "3rd Year", section: "B", room: "CS-Lab" },
    { day: "Tuesday", timeSlot: "Period 3", startTime: "11:15", endTime: "12:15", subject: "Digital Electronics", facultyName: "Prof. Priya Sharma", department: "Electronics", year: "3rd Year", section: "A", room: "EC-101" },
    { day: "Wednesday", timeSlot: "Period 1", startTime: "09:00", endTime: "10:00", subject: "Software Engineering", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "A", room: "CS-101" },
    { day: "Wednesday", timeSlot: "Period 2", startTime: "10:00", endTime: "11:00", subject: "Web Technologies", facultyName: "Prof. Priya Sharma", department: "Computer Science", year: "2nd Year", section: "A", room: "CS-Lab" },
    { day: "Thursday", timeSlot: "Period 1", startTime: "09:00", endTime: "10:00", subject: "Data Structures", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "A", room: "CS-101" },
    { day: "Thursday", timeSlot: "Period 2", startTime: "10:00", endTime: "11:00", subject: "Algorithms", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "B", room: "CS-102" },
    { day: "Friday", timeSlot: "Period 1", startTime: "09:00", endTime: "10:00", subject: "Computer Networks", facultyName: "Dr. Rajesh Kumar", department: "Computer Science", year: "3rd Year", section: "A", room: "CS-101" },
    { day: "Friday", timeSlot: "Period 2", startTime: "10:00", endTime: "11:00", subject: "Signals & Systems", facultyName: "Prof. Priya Sharma", department: "Electronics", year: "3rd Year", section: "A", room: "EC-201" },
  ];

  await db.insert(timetableTable).values(timetableEntries).onConflictDoNothing();
  console.log("Timetable seeded");

  console.log("✅ Seeding complete!");
  console.log("Login: admin@college.edu / faculty123");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed error:", err);
  process.exit(1);
});
