import { Router, type IRouter } from "express";
import { db, timetableTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { z } from "zod";

const router: IRouter = Router();

router.get("/current", async (req, res) => {
  const now = new Date();
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const dayName = days[now.getDay()];
  const currentTime = now.toTimeString().slice(0, 5); // HH:MM

  const entries = await db.select().from(timetableTable).where(eq(timetableTable.day, dayName));

  const current = entries.find((e) => e.startTime <= currentTime && currentTime <= e.endTime);

  if (!current) {
    res.json({ currentClass: null });
    return;
  }

  res.json({
    currentClass: {
      id: current.id,
      day: current.day,
      timeSlot: current.timeSlot,
      startTime: current.startTime,
      endTime: current.endTime,
      subject: current.subject,
      facultyName: current.facultyName,
      department: current.department,
      year: current.year,
      section: current.section,
      room: current.room,
    },
  });
});

router.get("/", async (req, res) => {
  const { day, department, year, section } = req.query;
  const conditions: any[] = [];

  if (day) conditions.push(eq(timetableTable.day, day as string));
  if (department) conditions.push(eq(timetableTable.department, department as string));
  if (year) conditions.push(eq(timetableTable.year, year as string));
  if (section) conditions.push(eq(timetableTable.section, section as string));

  const entries = conditions.length
    ? await db.select().from(timetableTable).where(and(...conditions))
    : await db.select().from(timetableTable);

  res.json(
    entries.map((e) => ({
      id: e.id,
      day: e.day,
      timeSlot: e.timeSlot,
      startTime: e.startTime,
      endTime: e.endTime,
      subject: e.subject,
      facultyName: e.facultyName,
      department: e.department,
      year: e.year,
      section: e.section,
      room: e.room,
    }))
  );
});

const createTimetableSchema = z.object({
  day: z.string().min(1),
  timeSlot: z.string().min(1),
  startTime: z.string().min(1),
  endTime: z.string().min(1),
  subject: z.string().min(1),
  facultyName: z.string().min(1),
  department: z.string().min(1),
  year: z.string().min(1),
  section: z.string().min(1),
  room: z.string().nullable().optional(),
});

router.post("/", async (req, res) => {
  const parsed = createTimetableSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }

  const [entry] = await db.insert(timetableTable).values(parsed.data).returning();

  res.status(201).json({
    id: entry.id,
    day: entry.day,
    timeSlot: entry.timeSlot,
    startTime: entry.startTime,
    endTime: entry.endTime,
    subject: entry.subject,
    facultyName: entry.facultyName,
    department: entry.department,
    year: entry.year,
    section: entry.section,
    room: entry.room,
  });
});

router.put("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

  const parsed = createTimetableSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }

  const [entry] = await db
    .update(timetableTable)
    .set(parsed.data)
    .where(eq(timetableTable.id, id))
    .returning();

  if (!entry) { res.status(404).json({ error: "Timetable entry not found" }); return; }

  res.json({
    id: entry.id,
    day: entry.day,
    timeSlot: entry.timeSlot,
    startTime: entry.startTime,
    endTime: entry.endTime,
    subject: entry.subject,
    facultyName: entry.facultyName,
    department: entry.department,
    year: entry.year,
    section: entry.section,
    room: entry.room,
  });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

  await db.delete(timetableTable).where(eq(timetableTable.id, id));
  res.json({ message: "Timetable entry deleted" });
});

export default router;
