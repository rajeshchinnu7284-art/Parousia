import { Router, type IRouter } from "express";
import { db, studentsTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import { z } from "zod";

const router: IRouter = Router();

router.get("/", async (req, res) => {
  const { department, year, section, search } = req.query;
  const conditions: any[] = [];

  if (department) conditions.push(eq(studentsTable.department, department as string));
  if (year) conditions.push(eq(studentsTable.year, year as string));
  if (section) conditions.push(eq(studentsTable.section, section as string));
  if (search) {
    conditions.push(
      sql`(${studentsTable.name} ILIKE ${`%${search}%`} OR ${studentsTable.registerNumber} ILIKE ${`%${search}%`})`
    );
  }

  const students = conditions.length
    ? await db.select().from(studentsTable).where(and(...conditions)).orderBy(studentsTable.name)
    : await db.select().from(studentsTable).orderBy(studentsTable.name);

  res.json(
    students.map((s) => ({
      id: s.id,
      name: s.name,
      registerNumber: s.registerNumber,
      department: s.department,
      year: s.year,
      section: s.section,
      photoPath: s.photoPath,
      createdAt: s.createdAt?.toISOString(),
    }))
  );
});

const createStudentSchema = z.object({
  name: z.string().min(1),
  registerNumber: z.string().min(1),
  department: z.string().min(1),
  year: z.string().min(1),
  section: z.string().min(1),
  photoPath: z.string().nullable().optional(),
});

router.post("/", async (req, res) => {
  const parsed = createStudentSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const [student] = await db
    .insert(studentsTable)
    .values(parsed.data)
    .returning();

  res.status(201).json({
    id: student.id,
    name: student.name,
    registerNumber: student.registerNumber,
    department: student.department,
    year: student.year,
    section: student.section,
    photoPath: student.photoPath,
    createdAt: student.createdAt?.toISOString(),
  });
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.id, id)).limit(1);
  if (!student) { res.status(404).json({ error: "Student not found" }); return; }

  res.json({
    id: student.id,
    name: student.name,
    registerNumber: student.registerNumber,
    department: student.department,
    year: student.year,
    section: student.section,
    photoPath: student.photoPath,
    createdAt: student.createdAt?.toISOString(),
  });
});

const updateStudentSchema = z.object({
  name: z.string().min(1).optional(),
  department: z.string().min(1).optional(),
  year: z.string().min(1).optional(),
  section: z.string().min(1).optional(),
  photoPath: z.string().nullable().optional(),
});

router.put("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

  const parsed = updateStudentSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }

  const [student] = await db
    .update(studentsTable)
    .set(parsed.data)
    .where(eq(studentsTable.id, id))
    .returning();

  if (!student) { res.status(404).json({ error: "Student not found" }); return; }

  res.json({
    id: student.id,
    name: student.name,
    registerNumber: student.registerNumber,
    department: student.department,
    year: student.year,
    section: student.section,
    photoPath: student.photoPath,
    createdAt: student.createdAt?.toISOString(),
  });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }

  await db.delete(studentsTable).where(eq(studentsTable.id, id));
  res.json({ message: "Student deleted" });
});

export default router;
