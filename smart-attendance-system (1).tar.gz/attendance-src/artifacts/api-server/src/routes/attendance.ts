import { Router, type IRouter } from "express";
import { db, attendanceTable, studentsTable, timetableTable } from "@workspace/db";
import { eq, and, gte, lte, sql, inArray } from "drizzle-orm";
import { z } from "zod";

const router: IRouter = Router();

router.get("/today", async (req, res) => {
  const today = new Date().toISOString().split("T")[0];
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const dayName = days[new Date().getDay()];

  const todayClasses = await db.select().from(timetableTable).where(eq(timetableTable.day, dayName));

  const classData = await Promise.all(
    todayClasses.map(async (cls) => {
      const totalStudents = await db
        .select({ count: sql<number>`count(*)` })
        .from(studentsTable)
        .where(
          and(
            eq(studentsTable.department, cls.department),
            eq(studentsTable.year, cls.year),
            eq(studentsTable.section, cls.section)
          )
        );

      const attendance = await db
        .select()
        .from(attendanceTable)
        .where(and(eq(attendanceTable.timetableId, cls.id), eq(attendanceTable.date, today)));

      const presentCount = attendance.filter((a) => a.status === "Present").length;
      const absentCount = attendance.filter((a) => a.status === "Absent").length;
      const total = Number(totalStudents[0]?.count ?? 0);

      return {
        timetableId: cls.id,
        subject: cls.subject,
        timeSlot: cls.timeSlot,
        department: cls.department,
        year: cls.year,
        section: cls.section,
        totalStudents: total,
        presentCount,
        absentCount,
        attendanceMarked: attendance.length > 0,
      };
    })
  );

  res.json({ date: today, classes: classData });
});

router.get("/summary", async (req, res) => {
  const { department, year, section, fromDate, toDate } = req.query;

  let studentsQuery = db.select().from(studentsTable);
  const sConditions: any[] = [];
  if (department) sConditions.push(eq(studentsTable.department, department as string));
  if (year) sConditions.push(eq(studentsTable.year, year as string));
  if (section) sConditions.push(eq(studentsTable.section, section as string));

  const students = sConditions.length
    ? await db.select().from(studentsTable).where(and(...sConditions))
    : await db.select().from(studentsTable);

  const summaries = await Promise.all(
    students.map(async (student) => {
      const aConditions: any[] = [eq(attendanceTable.studentId, student.id)];
      if (fromDate) aConditions.push(gte(attendanceTable.date, fromDate as string));
      if (toDate) aConditions.push(lte(attendanceTable.date, toDate as string));

      const records = await db.select().from(attendanceTable).where(and(...aConditions));
      const totalClasses = records.length;
      const presentCount = records.filter((r) => r.status === "Present").length;
      const absentCount = records.filter((r) => r.status === "Absent").length;
      const percentage = totalClasses > 0 ? (presentCount / totalClasses) * 100 : 0;

      return {
        studentId: student.id,
        studentName: student.name,
        registerNumber: student.registerNumber,
        department: student.department,
        year: student.year,
        section: student.section,
        totalClasses,
        presentCount,
        absentCount,
        percentage: Math.round(percentage * 10) / 10,
        isLowAttendance: percentage < 75,
      };
    })
  );

  res.json(summaries);
});

router.get("/export", async (req, res) => {
  const { department, year, section, fromDate, toDate } = req.query;

  const sConditions: any[] = [];
  if (department) sConditions.push(eq(studentsTable.department, department as string));
  if (year) sConditions.push(eq(studentsTable.year, year as string));
  if (section) sConditions.push(eq(studentsTable.section, section as string));

  const students = sConditions.length
    ? await db.select().from(studentsTable).where(and(...sConditions)).orderBy(studentsTable.name)
    : await db.select().from(studentsTable).orderBy(studentsTable.name);

  const summaries = await Promise.all(
    students.map(async (student) => {
      const aConditions: any[] = [eq(attendanceTable.studentId, student.id)];
      if (fromDate) aConditions.push(gte(attendanceTable.date, fromDate as string));
      if (toDate) aConditions.push(lte(attendanceTable.date, toDate as string));

      const records = await db.select().from(attendanceTable).where(and(...aConditions));
      const totalClasses = records.length;
      const presentCount = records.filter((r) => r.status === "Present").length;
      const percentage = totalClasses > 0 ? ((presentCount / totalClasses) * 100).toFixed(1) : "0.0";

      return {
        name: student.name,
        registerNumber: student.registerNumber,
        department: student.department,
        year: student.year,
        section: student.section,
        totalClasses,
        presentCount,
        absentCount: totalClasses - presentCount,
        percentage,
      };
    })
  );

  const headers = ["Name", "Register Number", "Department", "Year", "Section", "Total Classes", "Present", "Absent", "Attendance %"];
  const rows = summaries.map((s) =>
    [s.name, s.registerNumber, s.department, s.year, s.section, s.totalClasses, s.presentCount, s.absentCount, s.percentage].join(",")
  );

  const csv = [headers.join(","), ...rows].join("\n");

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="attendance_report.csv"`);
  res.send(csv);
});

router.get("/", async (req, res) => {
  const { date, timetableId, studentId, department, year, section, fromDate, toDate } = req.query;
  const conditions: any[] = [];

  if (date) conditions.push(eq(attendanceTable.date, date as string));
  if (timetableId) conditions.push(eq(attendanceTable.timetableId, parseInt(timetableId as string)));
  if (studentId) conditions.push(eq(attendanceTable.studentId, parseInt(studentId as string)));
  if (fromDate) conditions.push(gte(attendanceTable.date, fromDate as string));
  if (toDate) conditions.push(lte(attendanceTable.date, toDate as string));

  let studentIds: number[] | undefined;
  if (department || year || section) {
    const sConditions: any[] = [];
    if (department) sConditions.push(eq(studentsTable.department, department as string));
    if (year) sConditions.push(eq(studentsTable.year, year as string));
    if (section) sConditions.push(eq(studentsTable.section, section as string));

    const filteredStudents = await db.select({ id: studentsTable.id }).from(studentsTable).where(and(...sConditions));
    studentIds = filteredStudents.map((s) => s.id);
    if (studentIds.length > 0) {
      conditions.push(inArray(attendanceTable.studentId, studentIds));
    }
  }

  const records = conditions.length
    ? await db.select().from(attendanceTable).where(and(...conditions)).orderBy(attendanceTable.date)
    : await db.select().from(attendanceTable).orderBy(attendanceTable.date);

  const studentMap = new Map<number, { name: string; registerNumber: string }>();
  const timetableMap = new Map<number, string>();

  const uniqueStudentIds = [...new Set(records.map((r) => r.studentId))];
  const uniqueTimetableIds = [...new Set(records.map((r) => r.timetableId))];

  if (uniqueStudentIds.length > 0) {
    const students = await db.select().from(studentsTable).where(inArray(studentsTable.id, uniqueStudentIds));
    students.forEach((s) => studentMap.set(s.id, { name: s.name, registerNumber: s.registerNumber }));
  }
  if (uniqueTimetableIds.length > 0) {
    const timetables = await db.select().from(timetableTable).where(inArray(timetableTable.id, uniqueTimetableIds));
    timetables.forEach((t) => timetableMap.set(t.id, t.subject));
  }

  res.json(
    records.map((r) => ({
      id: r.id,
      studentId: r.studentId,
      studentName: studentMap.get(r.studentId)?.name ?? "Unknown",
      registerNumber: studentMap.get(r.studentId)?.registerNumber ?? "",
      timetableId: r.timetableId,
      subject: timetableMap.get(r.timetableId) ?? "Unknown",
      date: r.date,
      status: r.status,
      markedBy: r.markedBy,
      timestamp: r.timestamp?.toISOString(),
    }))
  );
});

const markAttendanceSchema = z.object({
  timetableId: z.number().int().positive(),
  date: z.string().min(1),
  records: z.array(
    z.object({
      studentId: z.number().int().positive(),
      status: z.enum(["Present", "Absent"]),
    })
  ),
});

router.post("/", async (req, res) => {
  const parsed = markAttendanceSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }

  const { timetableId, date, records } = parsed.data;

  await db
    .delete(attendanceTable)
    .where(and(eq(attendanceTable.timetableId, timetableId), eq(attendanceTable.date, date)));

  if (records.length > 0) {
    await db.insert(attendanceTable).values(
      records.map((r) => ({
        studentId: r.studentId,
        timetableId,
        date,
        status: r.status,
        markedBy: "manual",
      }))
    );
  }

  res.json({ message: "Attendance marked successfully", marked: records.length });
});

export default router;
