import React, { useState } from "react";
import { useListStudents, useDeleteStudent } from "@workspace/api-client-react";
import { Card, Button, Input, Select, Badge, Dialog } from "@/components/ui-core";
import { Link, useLocation } from "wouter";
import { Search, Plus, Edit2, Trash2, UserCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getInitials } from "@/lib/utils";

export default function Students() {
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("");
  const [yearFilter, setYearFilter] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: students, isLoading, refetch } = useListStudents({
    search: search || undefined,
    department: deptFilter || undefined,
    year: yearFilter || undefined,
  });

  const deleteMutation = useDeleteStudent({
    mutation: {
      onSuccess: () => {
        toast({ title: "Student deleted successfully" });
        setDeleteId(null);
        refetch();
      },
      onError: (err) => {
        toast({ title: "Error deleting student", variant: "destructive" });
      }
    }
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-display font-bold text-foreground">Students</h1>
          <p className="text-muted-foreground mt-2 text-lg">Manage student directory and profiles.</p>
        </div>
        <Link href="/students/add">
          <Button size="lg" className="w-full sm:w-auto">
            <Plus className="w-5 h-5 mr-2" /> Add Student
          </Button>
        </Link>
      </div>

      <Card className="p-4 sm:p-6 bg-white/50 backdrop-blur-sm border-none shadow-md">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input 
              placeholder="Search by name or register number..." 
              className="pl-12"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="w-full md:w-48">
            <Select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}>
              <option value="">All Departments</option>
              <option value="CSE">CSE</option>
              <option value="ECE">ECE</option>
              <option value="MECH">MECH</option>
            </Select>
          </div>
          <div className="w-full md:w-48">
            <Select value={yearFilter} onChange={(e) => setYearFilter(e.target.value)}>
              <option value="">All Years</option>
              <option value="1">1st Year</option>
              <option value="2">2nd Year</option>
              <option value="3">3rd Year</option>
              <option value="4">4th Year</option>
            </Select>
          </div>
        </div>
      </Card>

      {isLoading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>
      ) : students?.length === 0 ? (
        <div className="text-center py-24 bg-card rounded-2xl border border-border border-dashed">
          <UserCircle className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-foreground">No students found</h3>
          <p className="text-muted-foreground mt-2">Try adjusting your filters or add a new student.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {students?.map(student => (
            <Card key={student.id} className="overflow-hidden hover:shadow-lg transition-all duration-300 group">
              <div className="p-6 flex items-start gap-4 relative">
                {student.photoPath ? (
                  <img src={student.photoPath} alt={student.name} className="w-16 h-16 rounded-full object-cover border-2 border-primary/20" />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/80 to-primary flex items-center justify-center text-white font-bold text-xl shadow-inner">
                    {getInitials(student.name)}
                  </div>
                )}
                
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-bold text-foreground truncate">{student.name}</h3>
                  <p className="text-sm text-primary font-semibold mb-2">{student.registerNumber}</p>
                  <div className="flex flex-wrap gap-2">
                    <Badge>{student.department}</Badge>
                    <Badge variant="success">Yr {student.year} - {student.section}</Badge>
                  </div>
                </div>

                {/* Actions overlay on hover */}
                <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    variant="secondary" 
                    size="icon" 
                    className="w-8 h-8 rounded-full shadow-md"
                    onClick={() => setLocation(`/students/edit/${student.id}`)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="danger" 
                    size="icon" 
                    className="w-8 h-8 rounded-full shadow-md"
                    onClick={() => setDeleteId(student.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog 
        isOpen={deleteId !== null} 
        onClose={() => setDeleteId(null)}
        title="Delete Student"
      >
        <p className="text-muted-foreground mb-6">Are you sure you want to delete this student? This action cannot be undone.</p>
        <div className="flex justify-end gap-4">
          <Button variant="ghost" onClick={() => setDeleteId(null)}>Cancel</Button>
          <Button variant="danger" isLoading={deleteMutation.isPending} onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}>
            Delete Student
          </Button>
        </div>
      </Dialog>
    </div>
  );
}
