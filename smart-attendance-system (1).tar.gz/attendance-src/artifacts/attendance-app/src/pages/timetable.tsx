import React, { useState } from "react";
import { useListTimetable, useDeleteTimetableEntry, useCreateTimetableEntry } from "@workspace/api-client-react";
import { Card, Button, Badge, Dialog, Input, Select } from "@/components/ui-core";
import { Plus, Trash2, Clock, MapPin } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { formatClassTime } from "@/lib/utils";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

const entrySchema = z.object({
  day: z.string().min(1),
  timeSlot: z.string().min(1),
  startTime: z.string().min(1),
  endTime: z.string().min(1),
  subject: z.string().min(1),
  facultyName: z.string().min(1),
  department: z.string().min(1),
  year: z.string().min(1),
  section: z.string().min(1),
  room: z.string().optional(),
});

type EntryFormValues = z.infer<typeof entrySchema>;

export default function Timetable() {
  const { data: timetable, isLoading, refetch } = useListTimetable();
  const { toast } = useToast();
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedDay, setSelectedDay] = useState(DAYS[0]);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<EntryFormValues>({
    resolver: zodResolver(entrySchema),
    defaultValues: { day: selectedDay }
  });

  const createMutation = useCreateTimetableEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Class scheduled!" });
        setIsAddOpen(false);
        reset();
        refetch();
      }
    }
  });

  const deleteMutation = useDeleteTimetableEntry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Class removed from schedule." });
        refetch();
      }
    }
  });

  const handleAdd = (data: EntryFormValues) => {
    createMutation.mutate({ data });
  };

  const getClassesForDay = (day: string) => {
    return timetable?.filter(t => t.day === day).sort((a, b) => a.startTime.localeCompare(b.startTime)) || [];
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-display font-bold text-foreground">Timetable</h1>
          <p className="text-muted-foreground mt-2 text-lg">Manage weekly class schedules.</p>
        </div>
        <Button size="lg" onClick={() => setIsAddOpen(true)}>
          <Plus className="w-5 h-5 mr-2" /> Schedule Class
        </Button>
      </div>

      {/* Day Tabs */}
      <div className="flex overflow-x-auto pb-2 gap-2 hide-scrollbar">
        {DAYS.map(day => (
          <Button 
            key={day} 
            variant={selectedDay === day ? "primary" : "outline"}
            onClick={() => setSelectedDay(day)}
            className="rounded-full flex-shrink-0"
          >
            {day}
          </Button>
        ))}
      </div>

      {/* Classes List */}
      <div className="grid grid-cols-1 gap-4">
        {isLoading ? (
          <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>
        ) : getClassesForDay(selectedDay).length === 0 ? (
          <Card className="p-12 text-center border-dashed">
            <Clock className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <h3 className="text-xl font-bold">No classes scheduled</h3>
            <p className="text-muted-foreground mt-1">Click Schedule Class to add one for {selectedDay}.</p>
          </Card>
        ) : (
          getClassesForDay(selectedDay).map(entry => (
            <Card key={entry.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:shadow-md transition-shadow border-l-4 border-l-primary">
              <div className="flex items-center gap-6">
                <div className="text-center w-32 border-r border-border pr-6">
                  <p className="text-2xl font-display font-bold text-primary">{entry.startTime}</p>
                  <p className="text-sm font-semibold text-muted-foreground">to {entry.endTime}</p>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-2">{entry.subject}</h3>
                  <div className="flex flex-wrap gap-2 items-center">
                    <Badge variant="default">{entry.department} {entry.year}-{entry.section}</Badge>
                    <span className="text-sm font-medium flex items-center text-muted-foreground">
                      <MapPin className="w-4 h-4 mr-1" /> {entry.room || 'TBA'}
                    </span>
                  </div>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={() => deleteMutation.mutate({ id: entry.id })}
                disabled={deleteMutation.isPending}
              >
                <Trash2 className="w-5 h-5" />
              </Button>
            </Card>
          ))
        )}
      </div>

      <Dialog isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} title="Schedule Class">
        <form onSubmit={handleSubmit(handleAdd)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2">Day</label>
              <Select {...register("day")} error={errors.day?.message}>
                {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
              </Select>
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Time Slot Name</label>
              <Input {...register("timeSlot")} placeholder="Period 1" error={errors.timeSlot?.message} />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Start Time</label>
              <Input type="time" {...register("startTime")} error={errors.startTime?.message} />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">End Time</label>
              <Input type="time" {...register("endTime")} error={errors.endTime?.message} />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-2">Subject Name</label>
              <Input {...register("subject")} placeholder="e.g. Data Structures" error={errors.subject?.message} />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Department</label>
              <Select {...register("department")} error={errors.department?.message}>
                <option value="CSE">CSE</option>
                <option value="ECE">ECE</option>
                <option value="MECH">MECH</option>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Year & Section</label>
              <div className="flex gap-2">
                <Select {...register("year")} error={errors.year?.message}>
                  <option value="1">1st</option>
                  <option value="2">2nd</option>
                  <option value="3">3rd</option>
                  <option value="4">4th</option>
                </Select>
                <Select {...register("section")} error={errors.section?.message}>
                  <option value="A">A</option>
                  <option value="B">B</option>
                </Select>
              </div>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-2">Room / Lab (Optional)</label>
              <Input {...register("room")} placeholder="e.g. Lab 4" />
            </div>
            <div className="col-span-2 hidden">
               <Input {...register("facultyName")} value="Current User" />
            </div>
          </div>
          <div className="pt-4 flex justify-end gap-3">
            <Button variant="ghost" type="button" onClick={() => setIsAddOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createMutation.isPending}>Save Schedule</Button>
          </div>
        </form>
      </Dialog>
    </div>
  );
}
