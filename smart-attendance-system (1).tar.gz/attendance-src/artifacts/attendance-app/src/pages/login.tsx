import React from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button, Input, Card } from "@/components/ui-core";
import { LogIn } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const { login, user, isLoggingIn } = useAuth();
  const [, setLocation] = useLocation();

  React.useEffect(() => {
    if (user) {
      setLocation("/dashboard");
    }
  }, [user, setLocation]);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = (data: LoginForm) => {
    login(data);
  };

  return (
    <div className="min-h-screen w-full flex bg-background">
      {/* Left side - Image */}
      <div className="hidden lg:flex flex-1 relative bg-primary items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-primary/40 mix-blend-multiply z-10" />
        <img 
          src={`${import.meta.env.BASE_URL}images/login-bg.png`} 
          alt="University Campus" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 text-center p-12 text-white max-w-2xl">
          <img src={`${import.meta.env.BASE_URL}images/logo.png`} alt="Logo" className="w-24 h-24 mx-auto mb-8 drop-shadow-2xl" />
          <h1 className="text-5xl font-display font-bold mb-6 drop-shadow-lg">Smart Attendance System</h1>
          <p className="text-xl font-light text-white/90 drop-shadow">
            Streamline your classroom management with face recognition, real-time analytics, and automated reporting.
          </p>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="flex-1 flex items-center justify-center p-8 sm:p-12 lg:p-24 relative">
        <div className="w-full max-w-md space-y-8 relative z-10">
          <div className="text-center lg:text-left">
            <div className="lg:hidden flex justify-center mb-6">
              <img src={`${import.meta.env.BASE_URL}images/logo.png`} alt="Logo" className="w-20 h-20" />
            </div>
            <h2 className="text-4xl font-display font-bold text-foreground">Welcome Back</h2>
            <p className="mt-3 text-muted-foreground text-lg">Please sign in to your faculty account</p>
          </div>

          <Card className="p-8 border-none shadow-2xl shadow-primary/5 bg-white/60 backdrop-blur-xl">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Email Address</label>
                <Input 
                  type="email" 
                  placeholder="faculty@college.edu" 
                  {...register("email")}
                  error={errors.email?.message}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Password</label>
                <Input 
                  type="password" 
                  placeholder="••••••••" 
                  {...register("password")}
                  error={errors.password?.message}
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 rounded text-primary focus:ring-primary border-border" />
                  <span className="text-sm text-muted-foreground font-medium">Remember me</span>
                </label>
                <a href="#" className="text-sm font-semibold text-primary hover:text-primary/80 transition-colors">
                  Forgot Password?
                </a>
              </div>

              <Button type="submit" size="lg" className="w-full" isLoading={isLoggingIn}>
                {!isLoggingIn && <LogIn className="w-5 h-5 mr-2" />}
                Sign In to Portal
              </Button>
            </form>
          </Card>
          
          <div className="rounded-xl border border-border bg-muted/40 px-5 py-4 text-sm text-muted-foreground">
            <p className="font-semibold text-foreground mb-1">Demo Credentials</p>
            <p><span className="font-medium">Email:</span> admin@college.edu</p>
            <p><span className="font-medium">Password:</span> faculty123</p>
          </div>
        </div>
      </div>
    </div>
  );
}
