import React from "react";
import { useGetTodayAttendance, useGetAttendanceSummary } from "@workspace/api-client-react";
import { Card, Badge, Button } from "@/components/ui-core";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Users, UserCheck, UserX, ArrowRight, Activity } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: todayData, isLoading: todayLoading } = useGetTodayAttendance();
  const { data: summaryData, isLoading: summaryLoading } = useGetAttendanceSummary({
    // Fetch last 30 days summary as default
    fromDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    toDate: new Date().toISOString().split('T')[0]
  });

  const totalClassesToday = todayData?.classes.length || 0;
  const classesMarked = todayData?.classes.filter(c => c.attendanceMarked).length || 0;
  
  const avgAttendance = summaryData?.length 
    ? Math.round(summaryData.reduce((acc, curr) => acc + curr.percentage, 0) / summaryData.length)
    : 0;

  const lowAttendanceCount = summaryData?.filter(s => s.isLowAttendance).length || 0;

  const chartData = summaryData?.slice(0, 10).map(s => ({
    name: s.studentName.split(' ')[0], // First name for chart
    percentage: s.percentage
  })) || [];

  if (todayLoading || summaryLoading) {
    return <div className="flex justify-center items-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-display font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2 text-lg">Welcome back. Here's your overview for today.</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6 flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
            <Activity className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm font-semibold text-muted-foreground">Today's Classes</p>
            <p className="text-3xl font-display font-bold text-foreground">{classesMarked} / {totalClassesToday}</p>
          </div>
        </Card>
        
        <Card className="p-6 flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-14 h-14 rounded-2xl bg-success/10 flex items-center justify-center text-success">
            <UserCheck className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm font-semibold text-muted-foreground">Avg. Attendance</p>
            <p className="text-3xl font-display font-bold text-foreground">{avgAttendance}%</p>
          </div>
        </Card>

        <Card className="p-6 flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-14 h-14 rounded-2xl bg-warning/10 flex items-center justify-center text-warning">
            <UserX className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm font-semibold text-muted-foreground">Low Attendance Alert</p>
            <p className="text-3xl font-display font-bold text-foreground">{lowAttendanceCount}</p>
          </div>
        </Card>

        <Card className="p-6 flex items-center gap-4 hover:shadow-md transition-shadow">
          <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center text-accent-foreground">
            <Users className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm font-semibold text-muted-foreground">Total Students</p>
            <p className="text-3xl font-display font-bold text-foreground">{summaryData?.length || 0}</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Today's Classes List */}
        <Card className="lg:col-span-2 p-6 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-display font-bold">Today's Classes</h2>
            <Link href="/timetable">
              <Button variant="ghost" size="sm" className="text-primary">
                Full Timetable <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
          
          <div className="space-y-4 flex-1">
            {todayData?.classes.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                <Calendar className="w-12 h-12 mb-4 opacity-20" />
                <p>No classes scheduled for today.</p>
              </div>
            ) : (
              todayData?.classes.map((cls) => (
                <div key={cls.timetableId} className="flex items-center justify-between p-4 rounded-xl border border-border bg-background hover:bg-accent/20 transition-colors">
                  <div>
                    <h3 className="font-bold text-lg text-foreground">{cls.subject}</h3>
                    <p className="text-sm text-muted-foreground font-medium mt-1">
                      {cls.timeSlot} • {cls.department} {cls.year}-{cls.section}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    {cls.attendanceMarked ? (
                      <Badge variant="success">Marked ({cls.presentCount}/{cls.totalStudents})</Badge>
                    ) : (
                      <Link href={`/attendance?timetableId=${cls.timetableId}`}>
                        <Button size="sm">Mark Now</Button>
                      </Link>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Quick Chart */}
        <Card className="p-6">
          <h2 className="text-2xl font-display font-bold mb-6">Recent Trends</h2>
          <div className="h-[300px] w-full">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748B' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748B' }} />
                  <Tooltip 
                    cursor={{fill: 'transparent'}}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Bar dataKey="percentage" radius={[4, 4, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.percentage < 75 ? '#D32F2F' : '#27AE60'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                <p>Not enough data</p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
