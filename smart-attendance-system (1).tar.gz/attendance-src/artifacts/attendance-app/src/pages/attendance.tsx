import React, { useState, useEffect } from "react";
import { useListTimetable, useListStudents, useMarkAttendance, useGetTodayAttendance } from "@workspace/api-client-react";
import { Card, Button, Select, Input, Badge } from "@/components/ui-core";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { CheckCircle, XCircle, Save } from "lucide-react";
import { useLocation } from "wouter";

export default function Attendance() {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedClassId, setSelectedClassId] = useState<string>("");
  const { toast } = useToast();

  const { data: timetable } = useListTimetable();
  const selectedClass = timetable?.find(t => t.id.toString() === selectedClassId);
  
  const { data: students, isLoading: studentsLoading } = useListStudents(
    selectedClass ? { department: selectedClass.department, year: selectedClass.year, section: selectedClass.section } : undefined,
    { query: { enabled: !!selectedClass } }
  );

  // Use a map to track present/absent state locally before saving
  const [attendanceState, setAttendanceState] = useState<Record<number, 'Present' | 'Absent'>>({});

  // Initialize all as present when students load
  useEffect(() => {
    if (students && Object.keys(attendanceState).length === 0) {
      const initial: Record<number, 'Present' | 'Absent'> = {};
      students.forEach(s => initial[s.id] = 'Present');
      setAttendanceState(initial);
    }
  }, [students]);

  const toggleStatus = (id: number) => {
    setAttendanceState(prev => ({
      ...prev,
      [id]: prev[id] === 'Present' ? 'Absent' : 'Present'
    }));
  };

  const markAll = (status: 'Present' | 'Absent') => {
    if (!students) return;
    const newState: Record<number, 'Present' | 'Absent'> = {};
    students.forEach(s => newState[s.id] = status);
    setAttendanceState(newState);
  };

  const markMutation = useMarkAttendance({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Success", description: data.message });
      },
      onError: () => {
        toast({ title: "Error saving attendance", variant: "destructive" });
      }
    }
  });

  const handleSave = () => {
    if (!selectedClassId) return;
    const records = Object.entries(attendanceState).map(([studentId, status]) => ({
      studentId: Number(studentId),
      status
    }));

    markMutation.mutate({
      data: {
        timetableId: Number(selectedClassId),
        date,
        records
      }
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-display font-bold text-foreground">Manual Attendance</h1>
        <p className="text-muted-foreground mt-2 text-lg">Select a class and mark attendance manually.</p>
      </div>

      <Card className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold mb-2">Date</label>
            <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">Select Class</label>
            <Select value={selectedClassId} onChange={e => { setSelectedClassId(e.target.value); setAttendanceState({}); }}>
              <option value="">-- Choose Class --</option>
              {timetable?.map(t => (
                <option key={t.id} value={t.id}>{t.subject} ({t.timeSlot}) - {t.department} {t.year}-{t.section}</option>
              ))}
            </Select>
          </div>
        </div>
      </Card>

      {selectedClassId && (
        <Card className="overflow-hidden">
          <div className="p-6 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-muted/20">
            <div>
              <h2 className="text-xl font-bold font-display">{selectedClass?.subject}</h2>
              <p className="text-sm text-muted-foreground mt-1">Marking for {students?.length || 0} students</p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" onClick={() => markAll('Present')}>Mark All Present</Button>
              <Button variant="outline" size="sm" onClick={() => markAll('Absent')}>Mark All Absent</Button>
            </div>
          </div>

          {studentsLoading ? (
            <div className="p-12 flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>
          ) : (
            <div className="divide-y divide-border">
              {students?.map(student => {
                const status = attendanceState[student.id] || 'Present';
                const isPresent = status === 'Present';
                return (
                  <div key={student.id} className="p-4 flex items-center justify-between hover:bg-accent/10 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                        {student.registerNumber.slice(-3)}
                      </div>
                      <div>
                        <p className="font-bold text-foreground">{student.name}</p>
                        <p className="text-xs text-muted-foreground">{student.registerNumber}</p>
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => toggleStatus(student.id)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm transition-all ${
                        isPresent ? 'bg-success/15 text-success hover:bg-success/25' : 'bg-destructive/15 text-destructive hover:bg-destructive/25'
                      }`}
                    >
                      {isPresent ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                      {status}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <div className="p-6 bg-muted/20 border-t border-border flex justify-end">
            <Button size="lg" onClick={handleSave} isLoading={markMutation.isPending}>
              <Save className="w-5 h-5 mr-2" /> Save Attendance
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
