import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getInitials(name: string) {
  return name
    .split(' ')
    .map(n => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

export function formatClassTime(start: string, end: string) {
  return `${start} - ${end}`;
}

export function parseApiError(error: any): string {
  if (error?.error) return error.error;
  if (error?.message) return error.message;
  return "An unexpected error occurred.";
}
