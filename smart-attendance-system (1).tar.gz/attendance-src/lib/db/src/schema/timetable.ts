import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const timetableTable = pgTable("timetable", {
  id: serial("id").primaryKey(),
  day: text("day").notNull(),
  timeSlot: text("time_slot").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  subject: text("subject").notNull(),
  facultyName: text("faculty_name").notNull(),
  department: text("department").notNull(),
  year: text("year").notNull(),
  section: text("section").notNull(),
  room: text("room"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTimetableSchema = createInsertSchema(timetableTable).omit({ id: true, createdAt: true });
export type InsertTimetable = z.infer<typeof insertTimetableSchema>;
export type TimetableEntry = typeof timetableTable.$inferSelect;
